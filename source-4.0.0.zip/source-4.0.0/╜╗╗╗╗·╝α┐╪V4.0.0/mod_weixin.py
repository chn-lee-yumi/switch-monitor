# encoding: utf-8
import requests
import json

corpid = "wx1234srf52653"
corpsecret = "3125单4shtynuhjdrkf98134yqlrkjhf"


def refreshtoken():
    a = requests.get("https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + corpid + "&corpsecret=" + corpsecret).text
    a = json.loads(a)
    return a['access_token']


def sendweixinmsg(msg, agentid, token):
    datas = '{"touser": "@all","msgtype": "text","agentid": ' + str(agentid) + ',"text":{"content": "' + msg + '"}}'
    a = requests.post("https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=" + token,
                      data=datas.encode('utf-8'))
    print(msg)
    print(a.text)
