# encoding: utf-8
from mod_ping import *
from mod_weixin import *
from mod_cpu import *
import time
from threading import Timer

'''
TODO: 增加通过命令行参数来设置监控参数的功能
'''

# =============监控参数=============
DEAFULT_delay0 = 0.1  # 扫描间隔，秒，默认0.1
DEAFULT_CPU_INTERVAL = 1  # CPU扫描间隔，分钟，默认15
SWITCH_DOWN_ALERT_TIMES = 1  # 二层交换机连续多少轮扫描都offline才报警，默认8
THREE_TIER_SWITCH_DOWN_ALERT_TIMES = 2  # 三层交换机连续多少轮扫描都offline才报警，默认2
SWITCH_OVERLOAD_ALERT_TIMES = 1  # 二层交换机连续多少轮扫描都oerload才报警，默认3

# 变量定义
switch_numbers = {}  # 各楼栋二层交换机数目
three_tier_switch_down_times = {}  # 三层交换机down的扫描次数
three_tier_switch_down_time = {}  # 三层交换机down的时间
switch_down_times = {}  # 二层交换机down的扫描次数
switch_down_time = {}  # 二层交换机down的时间
switch_overload_times = {}  # 二层交换机overload的次数

# 初始化
switch_numbers[101] = 17
switch_numbers[102] = 17
switch_numbers[103] = 10
switch_numbers[104] = 18
switch_numbers[105] = 18
switch_numbers[106] = 19
switch_numbers[107] = 19
switch_numbers[108] = 19
switch_numbers[109] = 7
switch_numbers[110] = 21
switch_numbers[111] = 7
switch_numbers[112] = 16
switch_numbers[113] = 36
switch_numbers[114] = 36
switch_numbers[115] = 35
switch_numbers[121] = 19
switch_numbers[122] = 23
switch_numbers[123] = 30
switch_numbers[124] = 35
switch_numbers[125] = 31
switch_numbers[126] = 30
switch_numbers[127] = 28
switch_numbers[128] = 29
switch_numbers[129] = 28
switch_numbers[130] = 26
switch_numbers[131] = 23
switch_numbers[132] = 23
switch_numbers[133] = 28
switch_numbers[134] = 24
for a in list(range(101, 116)) + list(range(121, 135)):
    three_tier_switch_down_times[a] = 0
    three_tier_switch_down_time[a] = 0
    for b in range(1, switch_numbers[a] + 1):
        ip = "172.16." + str(a) + "." + str(b)
        switch_down_times[ip] = 0
        switch_down_time[ip] = 0
        switch_overload_times[ip] = 0


def checkswitch(ip):  # 检测交换机在线情况的函数
    a = pingip(ip)
    if a: return True
    return tcpingip(ip)


def offline():  # 检测到交换机offline
    if three_tier_switch_down_times[a] >= THREE_TIER_SWITCH_DOWN_ALERT_TIMES:
        sendweixinmsg(
            "Time: " + time.strftime("%X") + "\n汇聚交换机UP:\n172.16." + str(a) + ".254\n刚挂了" + str(int(
                (time.time() - three_tier_switch_down_time[a])) // 60) + "分钟", 4, token)
        three_tier_switch_down_times[a] = 0

    if switch_down_times[ip] == SWITCH_DOWN_ALERT_TIMES:
        sendweixinmsg("Time: " + time.strftime("%X") + "\n交换机炸了:\n" + ip, 3, token)  # 发送DOWN信息
    if switch_down_times[ip] == 1: switch_down_time[ip] = time.time()
    if switch_down_times[ip] == SWITCH_DOWN_ALERT_TIMES * 10: sendweixinmsg(
        "Time: " + time.strftime("%X") + "\n交换机" + ip + "\n已经炸了" + str(
            int((time.time() - switch_down_time[ip])) // 60) + "分钟！发生了什么？", 3,
        token)


def online():  # 检测到交换机online
    if switch_down_times[ip] >= SWITCH_DOWN_ALERT_TIMES:
        sendweixinmsg("Time: " + time.strftime("%X") + "\n交换机UP:\n" + ip + "\n刚挂了" + str(int(
            (time.time() - switch_down_time[ip])) // 60) + "分钟。", 3, token)  # 发送UP信息
    switch_down_times[ip] = 0
    if three_tier_switch_down_times[a] >= THREE_TIER_SWITCH_DOWN_ALERT_TIMES:
        sendweixinmsg("Time: " + time.strftime("%X") + "\n汇聚交换机UP:\n172.16." + str(a) + ".254\n刚挂了" + str(
            int((time.time() - three_tier_switch_down_time[a])) // 60) + "分钟。", 4, token)  # 发送UP信息
    three_tier_switch_down_times[a] = 0


def scancpu():
    a = 101
    b = 1
    while 1:
        ip = "172.16." + str(a) + "." + str(b)
        cpu = getcpuinfo(ip)
        if int(cpu[:-1]) >= 90:
            switch_overload_times[ip] = switch_overload_times[ip] + 1
            if switch_overload_times[ip] == SWITCH_OVERLOAD_ALERT_TIMES:
                sendweixinmsg("Time:\n" + time.strftime("%X") + "\n交换机过载:\n172.16." + str(
                    a) + "." + str(b) + "\nCPU load in last 5 minutes is " + cpu + "\n持续了" + str(
                    DEAFULT_CPU_INTERVAL * SWITCH_OVERLOAD_ALERT_TIMES) + "分钟，请检查一下。", 3, token)
            elif switch_overload_times[ip] == 20 * SWITCH_OVERLOAD_ALERT_TIMES:
                sendweixinmsg("Time:\n" + time.strftime("%X") + "\n这台交换机过载很长时间了！\nIP: 172.16." + str(
                    a) + "." + str(b) + "\nCPU load in last 5 minutes is " + cpu + "\n持续了" + str(
                    DEAFULT_CPU_INTERVAL * SWITCH_OVERLOAD_ALERT_TIMES * 20) + "分钟，请检查一下！！！", 3, token)
        else:
            if switch_overload_times[ip] >= SWITCH_OVERLOAD_ALERT_TIMES and cpu != "0%":
                sendweixinmsg("Time:\n" + time.strftime("%X") + "\n交换机CPU使用率变回正常\n刚过载了" + str(
                    SWITCH_OVERLOAD_ALERT_TIMES * switch_overload_times[ip]) + "分钟。\nIP: 172.16." + str(
                    a) + "." + str(b) + "\nCPU load in last 5 minutes is " + cpu + ".", 3, token)
            switch_overload_times[ip] = 0
        # 设置下一个交换机IP
        b = b + 1
        if b > switch_numbers[a]:  # 扫完本栋就下一栋
            a = a + 1
            b = 1
            if a == 116: a = 121
            if a == 135: break
        if a == 113 and b == 24: b = 25  # 这几台不存在
        if a == 105 and b == 6: b = 7
        if a == 109 and b == 1: b = 2
        if a == 106 and b == 15: b = 16  # 这台坏了很久
    # 设置下一次扫描
    timer_scancpu = Timer(DEAFULT_CPU_INTERVAL * 60, scancpu)
    timer_scancpu.start()


token = refreshtoken()
flag0 = time.strftime("%H")  # 刷新token的标记，一小时刷一次
flag1 = False  # 刷新token的标记，一小时刷一次
sendweixinmsg("Time: " + time.strftime("%X") + "\n监控在线", 2, token)  # 发送微信推送，监控在线
timer_scancpu = Timer(5, scancpu)  # 5秒后启动CPU使用率扫描
timer_scancpu.start()  # 5秒后启动CPU使用率扫描

a = 101
b = 1
while 1:  # 不断循环检测交换机直至手动终止程序
    time.sleep(DEAFULT_delay0)
    ip = "172.16." + str(a) + "." + str(b)
    if checkswitch(ip) == False:  # 重点：交换机下线的处理环节！！！！！！！！！！！！！！
        if tcpingip(ip) == False:  # TCP验证，如果还是offline
            switch_down_times[ip] = switch_down_times[ip] + 1
            # 判断是否汇聚交换机问题
            if pingip("172.16." + str(a) + "." + str(254)) == False:
                if tcpingip("172.16." + str(a) + "." + str(254)) == False:
                    if switch_down_times[ip] == 1: switch_down_times[
                        ip] = 0  # 可能有交换机是一直DOWN的，这个可以避免汇聚挂了复活之后给原来就DOWN的交换机重新报一次警
                    three_tier_switch_down_times[a] = three_tier_switch_down_times[a] + 1
                    if three_tier_switch_down_times[a] == THREE_TIER_SWITCH_DOWN_ALERT_TIMES:  # 汇聚交换机刚DOWN了
                        three_tier_switch_down_time[a] = time.time()
                        sendweixinmsg(
                            "Time: " + time.strftime("%X") + "\n汇聚炸了！！！\n172.16." + str(
                                a) + ".254", 4, token)  # 发送DOWN信息
                    if three_tier_switch_down_times[a] >= THREE_TIER_SWITCH_DOWN_ALERT_TIMES:
                        if three_tier_switch_down_times[a] == THREE_TIER_SWITCH_DOWN_ALERT_TIMES * 3:
                            sendweixinmsg(
                                "Time: " + time.strftime("%X") + "\n汇聚炸好久了！！！\n已经炸了" + str(int((
                                    time.time() -
                                    three_tier_switch_down_time[
                                        a])) // 60) + "分钟！！\n172.16." + str(
                                    a) + ".254\n请前往检查。", 4, token)  # 发送DOWN信息
                        a = a + 1  # 跳到下一栋
                        if a == 116: a = 121
                        if a == 135: a = 101
                        b = 1
                else:
                    offline()  # 如果不是汇聚问题，判断这台交换机offline
            else:
                offline()  # 如果不是汇聚问题，判断这台交换机offline
        else:
            online()  # 交换机是online的
    else:
        online()  # 交换机是online的

    # 设置下一个交换机IP
    b = b + 1
    if b > switch_numbers[a]:  # 扫完本栋就下一栋
        a = a + 1
        b = 1
        if a == 116: a = 121
        if a == 135: a = 101
    if a == 113 and b == 24: b = 25  # 这几台不存在
    if a == 105 and b == 6: b = 7
    if a == 109 and b == 1: b = 2
    if a == 106 and b == 15: b = 16  # 这台坏了很久

    # 每小时刷新一次token，且通报在线
    if time.strftime("%H") != flag0:
        flag1 = True
        flag0 = time.strftime("%H")
    if flag1 == True:
        flag1 = False
        token = refreshtoken()
        sendweixinmsg("Time: " + time.strftime("%X") + "\n监控在线", 2, token)
