# encoding: utf-8
import subprocess
import socket

'''
需要调用：ping
'''

tcpingtimeout = 2  # tcping超时时间，秒
socket.setdefaulttimeout(tcpingtimeout)


def pingip(ip):
    b = subprocess.Popen(["ping", "-w", "4", ip], shell=False, stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE)  # windows和linux都可用
    while 1:
        b.stdout.flush()
        line = b.stdout.readline().decode("gbk")
        if not line: break
        if line.find("TTL=") > 1 or line.find("ttl=") > 1: return True
    return False


def tcpingip(ip):
    a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    b = a.connect_ex((ip, 6666))
    a.close()
    if b == 10061 or b == 0: return True  # 拒绝连接或连接成功
    return False
