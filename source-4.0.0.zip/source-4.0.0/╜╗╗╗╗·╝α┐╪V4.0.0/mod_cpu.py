import telnetlib

password = "123456"  # 密码


def getcpuinfo(ip):
    try:
        # 连接Telnet服务器
        tn = telnetlib.Telnet(ip, port=23, timeout=2)
        # tn.set_debuglevel(2)
        # 输入登录密码
        tn.read_until('assword:'.encode('gbk'))
        tn.write(password.encode('gbk') + b'\n')
        # 登录完毕后执行命令
        tn.read_until('>'.encode('gbk'))
        command = "dis cpu\n"
        tn.write(command.encode('gbk'))
        tn.read_until("in last 1 minute\r\n    ".encode('gbk'))
        cpu = tn.read_until(" in last 5 minutes".encode('gbk'))
        # 执行完毕后关闭连接
        tn.close()
        # 接下来获取cpu使用率信息，此时cpu=b'13% in last 5 minutes'类似这样的数据
        cpu = cpu[:-18]  # 把百分号后面的都截掉
        return cpu  # 返回字符串，带百分号的
    except:  # 连接失败返回"0%"
        return "0%"
