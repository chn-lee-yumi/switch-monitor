from mod_reboot_switch import reboot_switch
import traceback
import time,threading
'''
for ip in ['172.16.104.15','172.16.124.35']:
    try:
        print(ip,reboot_switch(ip))
    except:
        a=traceback.format_exc()
        print(a[a.find('Error:')+7:])
'''
def reboot_switches(ips):
    for ip in ips:
        threading.Thread(target=reboot_switch,args=(ip,)).start()
    time.sleep(300)