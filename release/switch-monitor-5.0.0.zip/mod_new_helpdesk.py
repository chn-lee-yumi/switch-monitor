# encoding: utf-8

def send_incident(building_name, switch_ip):  # TODO：接入helpdesk
    pass
