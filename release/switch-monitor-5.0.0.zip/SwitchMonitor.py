#!/usr/bin/python
# encoding: utf-8
'''
说明：该脚本用于启动交换机监控。
'''
from Controller import start_switch_monitor

start_switch_monitor()
