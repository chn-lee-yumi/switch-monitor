# encoding: utf-8
import requests
import json
import time

corpid = "wx09adfgfhgj5af01ec36"
corpsecret = "Lh8fvzltkrjtrsed734w5beujn88fdthH8g3nMUUJl894v2"


def refreshtoken():
    t1 = time.time()
    a = requests.get("https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + corpid + "&corpsecret=" + corpsecret).text
    a = json.loads(a)
    t2 = time.time()
    print("连接微信服务器所用的时间：%.3f秒" % (t2 - t1))
    return a['access_token']


def sendweixinmsg(msg, agentid, token):
    t1 = time.time()
    datas = '{"touser": "@all","msgtype": "text","agentid": ' + str(agentid) + ',"text":{"content": "' + msg + '"}}'
    a = requests.post("https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=" + token,
                      data=datas.encode('utf-8'))
    print("**********************")
    print(msg)
    print(a.text)
    t2 = time.time()
    print("发送推送所用的时间：%.3f秒" % (t2 - t1))