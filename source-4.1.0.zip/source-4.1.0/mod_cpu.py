# encoding: utf-8
import telnetlib
import time

password = "123456"  # 密码
time_limit = 1  # 连接成功后超过这个时间还没获取到CPU数据的就放弃，秒


def getcpuinfo(ip):
    try:
        # 连接Telnet服务器
        tn = telnetlib.Telnet(ip, port=23, timeout=2)
        # tn.set_debuglevel(2)
        a = time.time()
        # 输入登录密码
        b = tn.read_until('assword:'.encode('gbk'), time_limit)
        if b == b"": return "0%"  # 有一台机（172.16.111.4）连上了什么数据也没有，专治这机
        tn.write(password.encode('gbk') + b'\n')
        # 登录完毕后执行命令
        tn.read_until('>'.encode('gbk'), time_limit)
        command = "dis cpu\n"
        tn.write(command.encode('gbk'))
        cpu = tn.read_until(" in last 5 minutes".encode('gbk'), time_limit)
        # 执行完毕后关闭连接
        tn.close()
        # 接下来获取cpu使用率信息
        cpu = cpu[-21:-18]  # 把百分号后面的都截掉
        return cpu.decode('gbk')  # 返回字符串，带百分号的
    except:  # 连接失败返回"0%"
        return "0%"


if __name__ == '__main__':
    cpu = getcpuinfo("172.16.111.1")
    print(cpu)
